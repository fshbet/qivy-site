# 08 — Data Contracts and Analytical Correctness

## Integration rule

Use supported Sisense data and query mechanisms. Do not independently access protected sources or bypass platform security.

## Data contract concerns

Model and validate:
- Dimensions and measures.
- Data types and semantic metadata.
- Series and categories.
- Aggregations and sorting.
- Filters and date hierarchies.
- Null, missing, duplicate, and invalid values.
- Empty data and partial data.
- High cardinality and platform limits.
- Formatting and units.
- Selection, cross-filtering, and drill-down where supported.

## Correctness requirements

- Keep calculation semantics separate from presentation logic.
- Do not silently change an aggregation or metric meaning when switching visual types.
- Define total/subtotal semantics explicitly.
- Test numeric precision and formatting boundaries.
- Validate incompatible field-to-role assignments.
- Do not fabricate sample data in production mode.
- Clearly label mock fixtures and development-only examples.
- Preserve platform filter and authorization behavior.

## Testing

Use unit tests for normalization, formatting, and schema validation. Use authorized integration tests for real Sisense query results, filter propagation, selection events, and lifecycle behavior. Mocks are not proof of platform integration.

## Performance

Set budgets based on representative data. Test large tables, high-cardinality dimensions, repeated filter updates, chart switching, and cleanup. Avoid unbounded browser-side data processing.

# 14 — Deployment, IT Approval, and Rollback

## Environment modes

### Local development
Use only authorized workspace files and permitted tools. Do not connect to protected systems without authorization.

### Non-production Sisense
Use only an explicitly authorized development/test instance. Validate registration, data binding, filters, lifecycle, configuration, packaging, and rollback.

### Production
Requires applicable IT approval, security review, administrator authorization, and change-management procedure. Do not deploy until all required approvals exist.

## IT review package

Include:
- Business case and scope.
- Architecture and data-flow diagrams.
- Compatibility matrix.
- Plugin and dependency inventory.
- License inventory.
- Permissions and security boundaries.
- Network/external-service requirements.
- Threat model and test evidence.
- Performance and accessibility findings.
- Installation, upgrade, rollback, and troubleshooting instructions.
- Known limitations and residual risks.
- Approval owners and status.

## Environment-specific installation

Never hardcode an assumed plugin directory. Verify the actual version's official installation procedure and administrator instructions. Cloud may not provide server filesystem access. Windows and Linux installation methods may differ by release.

Do not use unsupported endpoints or workarounds to bypass restricted access.

## Rollback

Document:
- Pre-deployment backup or artifact retention.
- Previous version identification.
- Rollback trigger and authorized owner.
- Restore procedure.
- Configuration/data migration implications.
- Post-rollback validation.
- Incident/escalation process.

Test rollback in an authorized non-production environment before production release when required.

## Release status vocabulary

- DEVELOPMENT ONLY
- BUILD VERIFIED
- NON-PRODUCTION INTEGRATION VERIFIED
- SECURITY REVIEWED
- IT APPROVED
- PRODUCTION DEPLOYED AND VERIFIED

Use only statuses supported by evidence.

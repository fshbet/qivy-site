# 12 — Implementation Roadmap and Vertical Slices

## Phase 1 — Discovery

Inspect the kit, workspace, version evidence, official docs, and deployment constraints. Deliver discovery, platform evidence, compatibility, and approval-dependency documents.

**Exit gate:** critical platform and access questions are answered or explicitly blocked.

## Phase 2 — Feasibility and requirements

Compare extension mechanisms and determine the support matrix. Inventory native Sisense features and select initial chart requirements.

**Exit gate:** reviewed feasibility matrix and acceptance criteria.

## Phase 3 — Architecture and UX

Create architecture diagrams, data flow, ADRs, property editor concept, persistence design, security boundaries, and test plan.

**Exit gate:** required architecture/security/IT approval is obtained.

## Phase 4 — Foundation

Create build/test configuration using verified and approved tooling. Establish type checking, linting, tests, quality gates, and a minimal integration scaffold.

**Exit gate:** repeatable build and automated checks.

## Phase 5 — First vertical slice

Implement one genuine visualization:
- Supported registration.
- Real Sisense data binding.
- Basic rendering.
- One or more meaningful property controls.
- Dashboard filter behavior as supported.
- Lifecycle cleanup.
- Configuration save/reload through the approved mechanism, if feasible.
- Unit and integration tests.
- Installation and rollback evidence in an authorized non-production environment.

**Exit gate:** evidence that the full slice works in the target test environment.

## Phase 6 — Core product

Add the gallery, high-value charts, table/pivot integration, configuration editor, themes, and presets incrementally.

## Phase 7 — Advanced capabilities

Add selected advanced charts and approved custom visual support only after core stability and requirements validation.

## Phase 8 — Hardening

Complete security, accessibility, performance, regression, compatibility, packaging, and upgrade testing.

## Phase 9 — Release preparation

Produce the IT submission package and release-readiness report. Production remains blocked until approval.

## Rules

- Do not install dependencies or deploy without authorization.
- Do not skip failed gates.
- Keep commits/changes small and reviewable.
- Update requirements, tests, docs, and handoff state after each slice.
- When blocked, record exact evidence needed and the safest next action.

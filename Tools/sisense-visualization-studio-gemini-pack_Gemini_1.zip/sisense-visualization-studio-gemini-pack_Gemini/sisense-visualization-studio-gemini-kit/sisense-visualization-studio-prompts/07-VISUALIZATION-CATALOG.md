# 07 — Visualization Catalog and Prioritization

## Principle

Do not implement charts merely to maximize count. Inventory what the target Sisense version already provides and identify gaps that justify this plugin.

## Candidate common charts

- Bar/column: grouped and stacked variants.
- Line and area.
- Pie and donut where appropriate.
- Scatter and bubble.
- Combo charts.
- Histogram and box plot.
- Heatmap.
- Treemap and sunburst.
- Waterfall and funnel.
- Radar/polar.
- Bullet/gauge.
- Pareto.
- Calendar heatmap.
- Geographic charts, subject to mapping support and licensing.

## Candidate advanced visuals

- Sankey and chord diagrams.
- Network/relationship graphs.
- Gantt/timeline.
- Cohort/retention heatmaps.
- Statistical distribution.
- Hierarchical drill-down.
- Decomposition/contribution.
- Small multiples.

Select an initial 6–8 high-value visuals based on actual business requirements and gaps in native Sisense capabilities.

## Tables and pivots

First evaluate native table/pivot support. Build a separate implementation only when there is a clear requirement that native functionality cannot meet.

If implementing pivot behavior, specify and test:
- Dimensions and measures.
- Grouping and aggregation.
- Subtotals/grand totals.
- Null/missing value behavior.
- Duplicate categories.
- Sorting and filtering.
- Number/date formatting.
- High-cardinality handling.
- Export behavior.
- Accessibility and keyboard interactions.

## Registry contract

Every visualization definition should include:
- Stable identifier, name, category, and purpose.
- Data roles and supported types/cardinality.
- Capability flags.
- Configuration schema and version.
- Supported interactions.
- Accessibility behavior and limitations.
- Performance notes.
- Compatibility requirements.
- Test coverage.

## Feature lifecycle

Each visual moves through: Proposed → Feasibility verified → Designed → Implemented → Unit tested → Integration tested → Target verified → Released.

Do not skip a state. Record blocked and unsupported states explicitly.

# 05 — Security, Privacy, and Governance

## Standards baseline

Follow organizational security policy first. Use relevant principles from OWASP ASVS, OWASP Top 10, and NIST Secure Software Development Framework as references, selecting applicable controls rather than claiming blanket compliance.

## Threat areas

Assess:
- Authentication and authorization boundaries.
- Native Sisense permissions and row-level security.
- XSS, unsafe HTML, DOM injection, and unsafe URL handling.
- Malformed or malicious configuration imports.
- Arbitrary code execution through custom visuals.
- Dependency vulnerabilities and software supply-chain risks.
- Sensitive information in logs and error messages.
- Credentials, tokens, and secrets in source or configuration.
- Prototype pollution and unsafe object merging.
- Resource exhaustion and oversized/high-cardinality data.
- CSP and browser security restrictions.
- Unauthorized telemetry or outbound network requests.
- Admin controls, auditability, and change management.

## Required rules

- Do not bypass Sisense authorization, data permissions, or row-level security.
- Client-side visibility checks are not authorization.
- Treat imported configurations and external metadata as untrusted.
- Do not execute arbitrary uploaded JavaScript as trusted code.
- Do not include credentials or sensitive data in templates.
- Do not add outbound telemetry without explicit approval.
- Use least privilege and approved dependencies.
- Keep production secrets outside the repository.
- Do not contact protected systems without authorization.
- Record threat scenarios, controls, test evidence, residual risks, and owners.

## Brand governance limitation

If mandatory brand enforcement is required, identify a trusted control point capable of enforcing it. Client-side code can provide a user experience and validation, but it must not be described as tamper-proof enforcement unless the architecture actually provides that guarantee.

## Security deliverables

- Threat model.
- Data-flow diagram.
- Permission matrix.
- Dependency and license inventory.
- Security test plan and findings.
- Residual-risk register.
- IT review evidence.

No unresolved critical/high findings should be hidden or silently downgraded. Exceptions require the designated risk owner.

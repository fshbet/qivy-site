# 04 — Architecture and Architecture Decision Records

## Architectural objective

Maximize reuse while respecting the real capabilities and restrictions of each Sisense environment.

## Proposed logical layers

### Shared core
- Visualization metadata and registry contracts.
- Configuration schemas and validation.
- Theme/design tokens.
- Formatting utilities.
- Shared visual property models.
- Accessibility helpers.
- Configuration migration.
- Platform-independent unit-tested logic.

### Platform adapters
Implement only after verification:
- Sisense registration and lifecycle.
- Data access and query binding.
- Dashboard filter and selection integration.
- Property/style editor integration.
- Configuration persistence.
- Diagnostics and platform events.

Adapters must not leak platform-specific types into the shared core unless a documented interface requires it.

### Visualization renderers
- Common charts.
- Advanced charts selected by requirements.
- Tables/pivots only where native platform capabilities are insufficient.
- Approved custom-visual adapter.

### Packaging
Build a package per supported extension mechanism when necessary. Include manifests, compiled assets, version metadata, dependency/license inventory, install instructions, validation instructions, and rollback instructions.

## Required architecture decisions

Record an ADR for:
- Selected extension mechanism per target.
- Shared core versus adapter boundaries.
- Rendering library and licensing.
- Property editor approach.
- Persistence strategy.
- Custom visual registration and trust model.
- Build/package tooling.
- Supported version policy.
- Brand-rule enforcement.
- Deployment model.

Each ADR must state context, options, evidence, decision, consequences, risks, and approval status.

## Key tradeoffs

- Reuse native Sisense capabilities where they meet requirements rather than rebuilding them.
- Do not choose Compose SDK or Fusion solely from familiarity; verify actual target support.
- Avoid a new backend unless shared storage or enforcement requires it and the organization approves it.
- Client-side controls alone cannot provide authoritative security or non-overridable organizational policy enforcement.
- Do not introduce new charting libraries without checking whether the target platform already provides a supported renderer and whether its license permits the intended use.

## Architecture approval gate

Before substantial implementation, present:
- Context and verified constraints.
- Proposed components and data flow.
- Mechanism-by-environment matrix.
- Dependency/license decisions.
- Security boundaries.
- Persistence and brand enforcement design.
- Deployment and rollback model.
- Open decisions and required approvals.

Do not mark a draft architecture as approved.

# 03 — Sisense Compatibility Matrix

## Target environments

The product goal is to support:
1. Sisense Cloud.
2. Sisense for Linux on-premises.
3. Sisense for Windows on-premises.

This is a target scope, not proof that all three support the same plugin mechanism.

## Required matrix

Maintain one row per supported product/version/deployment combination.

| Target | Exact version | Extension mechanism | API evidence | Build | Installed in authorized test | Real data | Filters/interactions | Persistence | Package/release status |
|---|---|---|---|---|---|---|---|---|---|
| Sisense Cloud | Unknown | Unknown | BLOCKED | Not run | Not run | Not run | Not run | Not run | BLOCKED |
| Sisense Linux | Unknown | Unknown | BLOCKED | Not run | Not run | Not run | Not run | Not run | BLOCKED |
| Sisense Windows | Unknown | Unknown | BLOCKED | Not run | Not run | Not run | Not run | Not run | BLOCKED |

Replace Unknown/Blocked only when supported by evidence.

## Mechanism evaluation

Evaluate, rather than assume, the applicability of:
- Fusion JavaScript add-ons / legacy custom widgets.
- Current supported plugin development mechanisms.
- Compose SDK custom widgets.
- Any other officially supported mechanism discovered for the target.

Do not conflate these mechanisms. They may differ in runtime, registration, APIs, editor integration, hosting, and deployment.

For each mechanism, document:
- Official documentation and supported versions.
- Runtime and framework requirements.
- Registration and lifecycle APIs.
- Data binding and filter integration.
- Style/property editor support.
- Persistence behavior.
- Cloud/on-premises availability.
- Windows/Linux support.
- Packaging and deployment.
- Public beta, preview, deprecation, or end-of-life status.
- Licensing and dependencies.

## Compatibility policy

- Shared-core tests do not replace platform-specific tests.
- A successful build does not prove the plugin can load.
- A browser mock does not prove Sisense data integration.
- Windows verification does not imply Linux verification.
- Linux verification does not imply Cloud verification.
- No production support claim without relevant evidence.
- If platform APIs differ, use separate adapters and packaging outputs.
- If a target cannot support a feature, document a clear limitation and an approved alternative.

## Version policy

Define minimum and maximum tested versions only after evidence is collected. Document known unsupported versions and deprecation risks. Avoid hardcoded deployment paths; use verified, environment-specific deployment instructions.

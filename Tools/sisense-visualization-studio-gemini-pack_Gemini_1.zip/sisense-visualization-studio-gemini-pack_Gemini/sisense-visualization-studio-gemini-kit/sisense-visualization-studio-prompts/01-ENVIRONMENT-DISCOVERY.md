# 01 — Environment Discovery and Evidence Collection

## Objective

Determine which Sisense products, versions, deployment models, and extension mechanisms are actually available. Do not infer them from the operating system alone.

## Known baseline from the prior discovery session

These are user-provided session findings, not independently revalidated by this package-generation process:

- No Sisense installation was found on the examined Windows machine.
- No `@sisense/*` package, credentials, instance configuration, or example plugin was found.
- The only local Sisense artifact reported was `E:\Downloads\Formula Functions _ Sisense Developers.pdf`.
- Node.js `v26.3.1` and npm `11.16.0` were reported as installed.
- The working directory was reported as a byte-identical copy of the production engineering kit: 46 files and matching aggregate SHA-256.
- The original kit was reported as untouched.
- The target use case is visualization inside Sisense dashboards.
- Deployment is restricted and requires IT approval.
- The earlier discovery compared a Fusion JS add-on (`prism.registerWidget`, plugin manifest and entry bundle) with Compose SDK custom widgets (`useCustomWidgets().registerCustomWidget`). These are distinct approaches; treat every API and compatibility statement as requiring fresh, version-specific verification.
- The earlier recommendation leaned toward a Fusion add-on, pending actual version and operating-system evidence. This is a provisional direction, not an approved architecture.

## Discovery tasks

1. Inspect the project folder and confirm whether it contains kit files, project files, or both.
2. Read the kit's root README, global instructions, standards, security notes, skills, quality gates, hooks, and release procedures.
3. Search only authorized local files for Sisense version indicators, manifests, plugin examples, SDK packages, and deployment documentation.
4. Identify available test environments and whether any are non-production.
5. Identify the actual Sisense version through an authorized administrator-provided About screen/export or approved API evidence. Do not contact an instance unless explicitly authorized.
6. Determine Cloud, Linux, Windows, or mixed deployment requirements.
7. Identify the supported extension APIs, lifecycle, data integration, configuration editor, persistence, packaging, and installation method for each target.
8. Identify dependency installation constraints, approved registries, licensing requirements, and IT review requirements.
9. Record evidence and confidence for each finding.

## Required output

Create/update:
- `docs/environment-discovery.md`
- `docs/platform-evidence.md`
- `docs/compatibility-matrix.md`
- `docs/approval-dependencies.md`
- `docs/decision-log.md`

Use the kit's established paths/conventions where required.

## Evidence format

For every critical claim, capture:
- Claim or capability.
- Target product/version.
- Source name and URL/path.
- Source type: official docs, installed artifact, administrator evidence, or test.
- Date checked.
- Status: VERIFIED / PARTIALLY VERIFIED / UNVERIFIED / BLOCKED / UNSUPPORTED.
- Consequence for architecture.
- Remaining evidence required.

## Stop conditions

Stop version-specific implementation if:
- The target Sisense version remains unknown.
- The extension mechanism is not documented for the target.
- Installation requires unavailable administrator access.
- The implementation would bypass a security or change-management control.
- A required dependency or license has not been approved.

Do not ask the user for facts already available in supplied files. Ask only targeted questions that cannot be resolved from authorized evidence.

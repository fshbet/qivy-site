# Sisense Visualization Studio — Gemini Web Project Pack

## Purpose

This package contains an individual Markdown prompt/document set for planning and building an enterprise-grade Sisense Visualization Studio, plus the original production engineering kit.

**Primary constraints**
- Target environments: Sisense Cloud, Sisense for Linux, and Sisense for Windows.
- Exact Sisense version and deployment model are initially unknown and must be discovered.
- Visualizations are intended to be used inside Sisense dashboards.
- Deployment is restricted and requires IT approval.
- The original production engineering kit must remain unchanged.
- No version-specific API, plugin manifest, package format, deployment path, or feature may be treated as verified without evidence.

## Package contents

- `production-engineering-kit.zip`: byte-for-byte copy of the original kit ZIP.
- `production-engineering-kit/`: extracted copy for convenient inspection; its files are unchanged.
- `sisense-visualization-studio-prompts/`: project-specific Markdown prompts and planning artifacts.
- `PACKAGE-MANIFEST.json`: SHA-256 inventory and packaging verification.
- `PACKAGE-VERIFICATION.md`: package contents and verification status.

## How to use this with Gemini Web

Gemini Web may not automatically retain every file or every decision between chats. Treat these files as a controlled project brief.

1. Upload this ZIP or the individual Markdown files to the Gemini conversation/workspace, depending on the capabilities available in your Gemini plan and interface.
2. Start with `00-MASTER-ORCHESTRATOR.md`.
3. Ask Gemini to read `01-ENVIRONMENT-DISCOVERY.md` and produce a discovery report before implementation.
4. Supply the latest project state, evidence, and unresolved questions when starting a new chat.
5. Work through the files in numerical order, but do not advance past a required approval gate just to complete the sequence.
6. After each work session, ask Gemini to update `16-GEMINI-HANDOFF-AND-STATE.md` and any affected project documents.
7. Keep the engineering kit separate and read-only. Apply its standards without silently editing its source files.
8. Store implementation source files in a separate project repository/folder, not inside the engineering kit.

## Suggested first Gemini message

> Read `00-MASTER-ORCHESTRATOR.md` and `01-ENVIRONMENT-DISCOVERY.md` from the uploaded project pack. Follow the existing production engineering kit. Do discovery only: inspect available files and evidence, classify findings, and produce an evidence-backed report. The Sisense version and deployment model are unknown. The target is dashboard-embedded visualization functionality across Sisense Cloud, Linux, and Windows, but no compatibility may be assumed. Deployment requires IT approval. Do not install dependencies, contact any Sisense instance, modify protected systems, deploy, or implement a version-specific integration until the discovery and approval gates are satisfied. Preserve all original kit files.

## Gemini operating discipline

- Ask for specific missing evidence only after checking the available files.
- Never claim to have inspected files that were not supplied or accessible.
- Never invent test results, API names, compatibility, or approval status.
- Do not put secrets, tokens, credentials, customer data, or production connection details into prompts.
- Prefer focused tasks and reviewable outputs.
- Each generated code change must identify files changed, assumptions, tests run, tests not run, and risks.
- A successful build is not proof of Sisense integration.
- A development artifact is not production-approved merely because it is packaged.

## Important note about platform compatibility

The desired support scope is Cloud, Linux, and Windows. This is a target, not a verified claim. Different environments or versions may require different adapters, packages, deployment workflows, or feature subsets. The final support statement must reflect actual evidence for each environment.

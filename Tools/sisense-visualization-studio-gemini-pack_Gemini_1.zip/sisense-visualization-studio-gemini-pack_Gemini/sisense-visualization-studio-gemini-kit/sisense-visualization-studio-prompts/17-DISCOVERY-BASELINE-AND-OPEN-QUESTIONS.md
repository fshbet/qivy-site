# 17 — Discovery Baseline and Open Questions

This document carries forward the prior discovery summary supplied in the conversation. It is a handoff aid, not an independently reproduced audit report.

## Reported findings

- The working folder was a byte-identical copy of the production engineering kit.
- The aggregate SHA-256 reportedly matched across 46 files.
- The original kit was reported as untouched.
- The kit's approval gate was reportedly inactive at the root because `.engineering/state.json` and the `PreToolUse` hook were under `project-template/`, not the root. Reinspect and follow the kit's documented setup; do not assume a gate is active merely because files exist.
- No Sisense installation was found at `C:\Program Files\Sisense`.
- No `@sisense/*` package, credentials, instance configuration, or example plugin was found.
- The only local Sisense artifact reported was `E:\Downloads\Formula Functions _ Sisense Developers.pdf`.
- Node.js `v26.3.1` and npm `11.16.0` were reported as installed.
- The initial discovery reviewed Fusion JS add-ons versus Compose SDK custom widgets. The mechanisms are distinct and need target-specific verification.
- The desired usage is inside Sisense dashboards.
- The target environment version and operating system remain unknown.
- A non-production Sisense instance and filesystem/admin access have not been confirmed.
- No dependencies were installed and no Sisense instance was contacted in that discovery session.

## Important decisions

- Do not select a mechanism solely because it works on a local machine.
- Verify Cloud, Linux, and Windows separately.
- Do not implement version-specific code before resolving the compatibility gate.
- Do not write mechanism-specific security/deployment documents as if the mechanism were already selected. The documents in this pack are planning prompts; convert them into evidence-based project documents once the target is known.
- The user wants a complete individual-Markdown workflow suitable for Gemini Web.

## First questions to resolve from evidence

1. What exact Sisense version is targeted?
2. Which deployment models are actually in scope: Cloud, Linux, Windows, or all three?
3. Is there an authorized non-production instance?
4. What extension installation path is supported for each target?
5. Who can approve plugin/dependency review and deployment?
6. Which existing Sisense charts, tables, and pivots should be reused rather than rebuilt?
7. Which initial business scenarios justify the first 6–8 visualizations?
8. Is shared template persistence required across users, teams, and environments?
9. Are brand rules advisory, or must they be technically non-overridable?
10. Are external package registries and new dependencies allowed?

## Decision rule

If the answers differ across Cloud, Linux, and Windows, do not force a single deployment design. Use the shared core where feasible and create separate supported adapters/packages.

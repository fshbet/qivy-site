# 09 — Branding, Themes, and Organizational Policy

## Brand profile model

A brand profile may contain:
- Stable ID and name.
- Approved palette.
- Primary, secondary, accent, and semantic colors.
- Typography.
- Logo assets, where permitted.
- Text, background, surface, and border colors.
- Chart-specific defaults.
- Number/date formatting defaults.
- Accessibility constraints.
- Owner, version, and change metadata.

Support multiple brands or business-unit profiles only where required.

## Precedence

1. Mandatory organizational policy.
2. Approved brand profile.
3. Dashboard/project defaults.
4. Saved visualization configuration.
5. User-level temporary overrides, where permitted.

Define each property as locked, overridable, or editable. Provide clear UI feedback when an option is locked.

## Enforcement boundary

Determine where the authoritative policy can be enforced. A browser-side theme selector can improve consistency but cannot by itself guarantee non-overridable policy against a modified client. If no supported trusted enforcement point exists, label the control as guidance/convention and document the limitation.

## Accessibility

Validate palette contrast and avoid conveying information solely through color. Provide semantic alternatives such as patterns, labels, icons, or table equivalents where suitable.

## Change management

Version brand profiles. Define ownership, approval, backward compatibility, migration, and rollback. Do not embed confidential brand assets or secrets in publicly distributed packages.

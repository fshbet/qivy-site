# 06 — UX, Visual Design, and Accessibility

## Experience goal

Create a professional visualization authoring experience integrated into the supported Sisense dashboard workflow, not a separate application unless platform limitations require one and approval is granted.

## Proposed interaction model

- Searchable visualization gallery.
- Central preview.
- Contextual property panel.
- Data/series mapping area where supported.
- Brand/theme selector.
- Save, duplicate, reset, undo/redo where feasible.
- Preview and apply workflow consistent with the native platform lifecycle.
- Clear validation, loading, empty, error, and success states.

Validate the layout against the actual extension host. Do not assume that a standalone editor can be embedded in every target.

## Design controls

Expose only controls applicable to the selected visual:
- Colors, palettes, semantic colors, and gradients.
- Typography and hierarchy.
- Title, subtitle, descriptions, annotations.
- Axes, scales, ranges, labels, ticks, and formats.
- Legend placement.
- Data labels and collision behavior.
- Tooltip content and formatting.
- Gridlines, borders, surfaces, spacing, and dimensions.
- Series, markers, line weight, bar spacing, transparency.
- Thresholds, reference lines, targets, and conditional rules.
- Number, currency, percentage, date, and custom formats.
- Responsive behavior and reduced motion.

Preserve analytical semantics when switching chart types.

## Accessibility

Target WCAG 2.2 AA where applicable. Validate:
- Keyboard navigation and visible focus.
- Semantic labels and accessible control names.
- Contrast and non-color-only encoding.
- Screen-reader support.
- Reduced motion.
- Table alternatives and accessible summaries for charts.
- Validation messages and error recovery.
- Responsive layouts.

Automated scans alone are not proof of full accessibility. Document unsupported cases and manual checks.

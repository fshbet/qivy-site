# 13 — Test Strategy and Quality Gates

## Engineering kit alignment

Use the production engineering kit's required checks and scripts. Do not create a competing quality process or claim that a project-specific check replaces a mandatory kit gate.

## Test layers

- Unit tests: schemas, normalization, formatting, style precedence.
- Component tests: property controls, gallery, configuration interactions.
- Integration tests: adapters and supported platform APIs.
- Analytical tests: aggregation semantics, pivot totals, nulls, duplicates, precision.
- Security tests: import validation, XSS defenses, dependency checks, permission boundaries.
- Accessibility tests: automated and manual keyboard/screen-reader checks.
- Performance tests: large data, repeated filter updates, chart switching, cleanup.
- Compatibility tests: separate target matrix per Cloud/Linux/Windows and version.
- Release tests: package validation, installation, upgrade, rollback.

## Evidence discipline

Record the exact command, environment, date, exit code, output summary, and artifact location for each executed test. Never invent or infer successful results.

Mark a test as NOT RUN if it was not executed. Mark platform integration as BLOCKED if no authorized environment was available.

## Release-blocking issues

Define severity and ownership. No critical/high security, data correctness, or release-blocking compatibility issue may be hidden. Exceptions require documented approval by the designated owner.

## Minimum acceptance

- Reproducible build in the approved environment.
- Mandatory quality gates pass.
- Unit and integration tests pass for implemented functionality.
- Target environment is tested for any claimed supported release.
- Packaging and rollback are validated.
- Known limitations and residual risks are documented.

# 15 — Release Readiness Checklist

## Platform and compatibility
- [ ] Exact target version and deployment model recorded.
- [ ] Official API and manifest evidence recorded.
- [ ] Cloud, Linux, and Windows compatibility separately classified.
- [ ] Every claimed supported environment tested.
- [ ] Deprecation/preview status and upgrade risks documented.

## Functionality
- [ ] Implemented features trace to requirements.
- [ ] Real Sisense data binding verified.
- [ ] Dashboard interactions verified where supported.
- [ ] Configuration persistence verified where claimed.
- [ ] Native table/pivot reuse assessed.
- [ ] Custom visual registration is controlled and documented.

## Security and governance
- [ ] Threat model reviewed.
- [ ] Authorization and data boundaries verified.
- [ ] Dependency and license inventory complete.
- [ ] Import validation and unsafe content protections tested.
- [ ] Logging and telemetry reviewed.
- [ ] Brand policy enforcement claims match the real control point.
- [ ] Residual risks have owners and approvals.

## Quality
- [ ] Production engineering kit gates pass.
- [ ] Tests and evidence recorded.
- [ ] Accessibility checks completed.
- [ ] Performance budgets and tests completed.
- [ ] Regression tests pass.
- [ ] No hidden critical/high release blockers.

## Operations
- [ ] Package built reproducibly.
- [ ] Installation steps verified.
- [ ] Upgrade steps documented.
- [ ] Rollback validated as required.
- [ ] Troubleshooting and support ownership documented.
- [ ] IT and change approvals recorded.

## Decision

Select exactly one:
- NOT READY
- READY FOR NON-PRODUCTION VALIDATION
- READY FOR IT REVIEW
- APPROVED FOR PRODUCTION
- PRODUCTION VERIFIED

Do not select a status based on optimism or successful compilation alone.

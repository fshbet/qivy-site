# 10 — Persistence and Reusable Configurations

## Required capabilities to evaluate

- Personal saved presets.
- Shared team templates.
- Organization-approved templates.
- Saved chart styles and themes.
- Duplicate, rename, search, tags, and favorites.
- Import/export of validated configurations.
- Version history and restoration where supported.
- Schema migration.
- Ownership and modification metadata.

## Storage decision

Investigate native Sisense persistence options first. Do not assume local browser storage provides enterprise sharing, backup, auditability, or access control.

If shared persistence requires a backend, database, or additional service:
1. Document the requirement.
2. Identify security, hosting, cost, and operations implications.
3. Obtain organizational approval before implementation.
4. Provide a no-additional-service fallback only if it meets the requirements.

## Schema and validation

Use stable IDs and explicit schema versions. Validate all imports. Reject unknown unsafe fields and excessive input sizes. Migrate older versions with tested, deterministic transformations.

Never store credentials or sensitive source data in presets.

## Governance

Define owner, visibility, sharing, permissions, retention, concurrency/conflict handling, audit requirements, and deletion behavior. Do not expose shared templates to users who lack authorization.

# Project Engineering Instructions

Read `docs/project-context.md`, `docs/requirements.md`, `docs/acceptance-criteria.md`, applicable `docs/standards/` and the global Production Engineering Constitution.

## Required workflow
- Use `/production-app` for new applications or major changes.
- Before substantial implementation, produce requirements, architecture, threat model, UX plan, test strategy, deployment plan and milestone backlog.
- Wait for explicit human approval. Do not update `.engineering/state.json` or approve your own plan.
- Work milestone by milestone. Add tests and docs with each meaningful change.
- Do not claim checks passed unless they ran; retain evidence.
- Run `/verify-release-readiness` before declaring a release ready.

## Project-specific facts
Fill out `docs/project-context.md`; do not infer missing values as facts.

## Quality gates
Use `.engineering/quality-gates.json` and `.github/workflows/ci.yml`. Replace example commands with the real stack commands. A placeholder is not a passed gate.

## Security and safety
- Preserve user changes.
- Do not commit secrets or sensitive production data.
- Do not execute destructive commands or production migrations without explicit authorization.
- Require server-side authorization and deny-by-default behavior for protected resources.
- Record material architecture changes as ADRs.

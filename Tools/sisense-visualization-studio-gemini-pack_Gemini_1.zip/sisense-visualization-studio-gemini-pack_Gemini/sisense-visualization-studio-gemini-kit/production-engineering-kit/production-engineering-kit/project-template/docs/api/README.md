Store API contracts (for example OpenAPI specifications), compatibility notes and examples here.

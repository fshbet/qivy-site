# Test Plan

## Scope and risks
TBD

## Test environments and test data
TBD. Never use production secrets or unsafe production data.

## Test levels
- Unit:
- Integration:
- API/contract:
- End-to-end:
- Regression:
- Security:
- Accessibility:
- Performance/reliability:
- Migration/recovery:
- Deployment smoke tests:

## Acceptance-criteria traceability
| Acceptance ID | Test ID | Test type | Command/tool | Expected evidence |
|---|---|---|---|---|
| AC-001 | TBD | TBD | TBD | TBD |

## Entry and exit criteria
TBD

## Results
Record exact command, environment, date, exit code, passed/failed/skipped counts and artifact links. Do not fabricate results.

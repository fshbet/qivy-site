Store user journeys, wireframes, design tokens, accessibility decisions and UX validation evidence here.

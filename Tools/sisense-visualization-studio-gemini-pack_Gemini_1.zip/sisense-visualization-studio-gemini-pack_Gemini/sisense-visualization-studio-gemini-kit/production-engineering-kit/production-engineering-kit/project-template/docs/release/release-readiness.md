# Release Readiness Report

- Release / commit:
- Environment:
- Reviewer:
- Date:
- Recommendation: GO / NO-GO / NOT VERIFIED

## Acceptance criteria
| ID | Status | Evidence |
|---|---|---|
| AC-001 | Not verified | TBD |

## Quality gates
| Gate | Command/tool | Result | Evidence | Limitations |
|---|---|---|---|---|
| Lint/format | TBD | Not run | TBD | TBD |
| Type/static checks | TBD | Not run | TBD | TBD |
| Unit/integration/E2E | TBD | Not run | TBD | TBD |
| Security/dependencies/secrets | TBD | Not run | TBD | TBD |
| Accessibility | TBD | Not run | TBD | TBD |
| Build/package | TBD | Not run | TBD | TBD |
| Deployment smoke test | TBD | Not run | TBD | TBD |

## Open defects and security findings
TBD

## Operational readiness
Monitoring, backup/restore, rollback, runbooks and ownership: TBD

## Residual risks and exceptions
TBD

## Approval
This report is evidence for a decision, not authorization to deploy.

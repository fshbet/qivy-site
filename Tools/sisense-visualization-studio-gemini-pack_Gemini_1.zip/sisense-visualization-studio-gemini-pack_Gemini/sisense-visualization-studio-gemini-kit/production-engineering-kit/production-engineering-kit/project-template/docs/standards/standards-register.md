# Standards Register

For each project, verify current versions, applicability, organization policies and required evidence.

| Area | Candidate reference | Applicable? | Selected scope/version | Evidence / exception |
|---|---|---|---|---|
| Secure SDLC | NIST SSDF | TBD | TBD | TBD |
| Web application security | OWASP ASVS | TBD | TBD | TBD |
| API security | OWASP API Security guidance | TBD | TBD | TBD |
| Web accessibility | WCAG 2.2 AA | TBD | TBD | TBD |
| Software quality | ISO/IEC 25010 | TBD | TBD | TBD |
| Language/framework security | Official language/framework guidance | TBD | TBD | TBD |
| Organization policy | Internal security/privacy/release policy | TBD | TBD | TBD |

Do not claim certification or formal compliance unless the required assessment and authorization actually occurred.

# ADR-NNN: Decision title

- Status: Proposed / Accepted / Superseded
- Date:
- Decision owner:

## Context
What problem or constraint requires a decision?

## Decision
What is chosen?

## Alternatives considered
List realistic alternatives.

## Consequences
Trade-offs, risks, cost, operational implications and migration impact.

## Verification
How will the decision be validated?

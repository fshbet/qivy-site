# Acceptance Criteria

Write criteria so a reviewer can determine pass/fail without guessing.

| ID | Requirement | Given / When / Then | Evidence / test | Status |
|---|---|---|---|---|
| AC-001 | TBD | Given ... When ... Then ... | TBD | Not verified |

Include as applicable:
- Happy path and boundary cases.
- Invalid input and error states.
- Authentication and authorization, including denied access.
- Tenant/resource isolation.
- Data persistence and migration behavior.
- Accessibility and responsive behavior.
- Performance and reliability.
- Deployment and operational behavior.

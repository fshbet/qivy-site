# Requirements

## Problem statement
TBD

## Users and roles
TBD

## Functional requirements
| ID | Requirement | Priority | Status |
|---|---|---|---|
| FR-001 | TBD | TBD | Proposed |

## Non-functional requirements
| ID | Area | Requirement / measurable target | Verification |
|---|---|---|---|
| NFR-001 | Security | TBD | TBD |
| NFR-002 | Performance | TBD | TBD |
| NFR-003 | Accessibility | TBD | TBD |
| NFR-004 | Reliability | TBD | TBD |
| NFR-005 | Maintainability | TBD | TBD |

## Data and privacy
TBD

## Integrations and dependencies
TBD

## Assumptions
TBD

## Out of scope
TBD

## Open questions
TBD

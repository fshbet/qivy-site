# Deployment Runbook

## Scope and target environment
TBD

## Prerequisites and approvals
TBD

## Configuration and secrets
Reference secret names only; never paste secret values.

## Build and artifact provenance
TBD

## Database migrations
- Pre-checks:
- Backup:
- Migration command:
- Validation:
- Recovery/rollback limitations:

## Deployment steps
TBD

## Health checks and smoke tests
TBD

## Monitoring and alerts
TBD

## Rollback procedure
TBD

## Backup and restore verification
TBD

## Incident contacts / escalation
TBD

## Post-deployment evidence
TBD

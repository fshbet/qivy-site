# Project Context

Complete this document during discovery. Mark unknown items as `TBD`; do not invent them.

- Product name:
- Business purpose:
- User groups and personas:
- Application profile: (web/SaaS, mobile, desktop, API, data/BI, AI, automation, other)
- Repository status: (greenfield/existing)
- Frontend and version:
- Backend and version:
- Database and version:
- Identity provider / authentication:
- Hosting / deployment target:
- Data classification and retention:
- Regulatory/contractual obligations:
- Availability / performance expectations:
- Accessibility target:
- External integrations:
- Environments (dev/test/staging/prod):
- CI/CD platform:
- Logging/monitoring:
- Backup and recovery expectations:
- Organization-specific policies:
- Known constraints and assumptions:

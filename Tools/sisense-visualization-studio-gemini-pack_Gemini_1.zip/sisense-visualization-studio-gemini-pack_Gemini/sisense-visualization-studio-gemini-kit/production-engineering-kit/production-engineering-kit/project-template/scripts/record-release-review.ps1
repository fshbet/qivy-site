$ErrorActionPreference = "Stop"
$statePath = ".engineering/state.json"
if (-not (Test-Path $statePath)) { throw "Missing $statePath." }
$state = Get-Content $statePath -Raw | ConvertFrom-Json
Write-Host "This records a recommendation only; it does not deploy or authorize deployment."
$recommendation = Read-Host "Enter GO, NO-GO, or NOT-VERIFIED"
if ($recommendation -notin @("GO", "NO-GO", "NOT-VERIFIED")) { throw "Invalid recommendation." }
if (-not (Test-Path "docs/release/release-readiness.md")) { throw "Release readiness report missing." }
$state.release_review_recorded = $true
$state.release_recommendation = $recommendation
$state.release_review_recorded_at = (Get-Date).ToString("o")
$state | ConvertTo-Json -Depth 10 | Set-Content $statePath -Encoding UTF8
Write-Host "Recommendation recorded: $recommendation"

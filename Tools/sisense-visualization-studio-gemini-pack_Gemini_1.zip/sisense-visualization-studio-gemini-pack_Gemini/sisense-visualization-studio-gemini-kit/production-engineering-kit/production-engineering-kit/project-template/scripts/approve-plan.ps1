$ErrorActionPreference = "Stop"
$statePath = ".engineering/state.json"
if (-not (Test-Path $statePath)) {
    throw "Missing $statePath. Run this script from the repository root."
}
$requiredFiles = @(
    "docs/requirements.md",
    "docs/acceptance-criteria.md",
    "docs/architecture/architecture.md",
    "docs/security/threat-model.md",
    "docs/testing/test-plan.md",
    "docs/ux/ux-plan.md",
    "docs/operations/deployment-runbook.md"
)
$missing = @($requiredFiles | Where-Object { -not (Test-Path $_) })
if ($missing.Count -gt 0) {
    throw "Required planning documents are missing: $($missing -join ', ')"
}
$state = Get-Content $statePath -Raw | ConvertFrom-Json
Write-Host "Review the requirements, acceptance criteria, architecture, threat model, UX plan, test plan and deployment plan."
$confirmation = Read-Host "Type APPROVE-IMPLEMENTATION only if you personally approve the plan"
if ($confirmation -cne "APPROVE-IMPLEMENTATION") {
    throw "Approval not recorded."
}
$state.phase = "implementation_approved"
$state.plan_approved_by_human = $true
$state.plan_approved_at = (Get-Date).ToString("o")
$state | ConvertTo-Json -Depth 10 | Set-Content $statePath -Encoding UTF8
Write-Host "Human approval recorded. This does not approve production deployment."

#!/usr/bin/env python3
"""Claude Code PreToolUse hook: fail closed for direct edit tools before human plan approval."""
import json
import sys
from pathlib import Path

PROTECTED_PATHS = (
    ".engineering/state.json",
    ".engineering/hooks/enforce_phase.py",
    "scripts/approve-plan.ps1",
    "scripts/record-release-review.ps1",
)

def main():
    try:
        payload = json.load(sys.stdin)
        tool_input = payload.get("tool_input") or {}
        target = str(tool_input.get("file_path") or tool_input.get("path") or "").replace("\\", "/")
        normalized = target.lower()
        if any(item.lower() in normalized for item in PROTECTED_PATHS):
            print("BLOCKED: approval state, enforcement hook, and human approval scripts are protected. A human must make these changes outside the agent.", file=sys.stderr)
            return 2

        state_path = Path(".engineering/state.json")
        if not state_path.exists():
            print("BLOCKED: .engineering/state.json is missing. Initialize the engineering template and obtain human approval.", file=sys.stderr)
            return 2
        # utf-8-sig supports JSON written by Windows PowerShell versions that emit a UTF-8 BOM.
        state = json.loads(state_path.read_text(encoding="utf-8-sig"))
        if state.get("phase") != "implementation_approved" or state.get("plan_approved_by_human") is not True:
            print(
                "BLOCKED: implementation is not approved. Complete requirements, architecture, security, UX and test planning; "
                "present the plan to the user; the human must run scripts/approve-plan.ps1 after review.",
                file=sys.stderr
            )
            return 2
        return 0
    except Exception as exc:
        print(f"BLOCKED: unable to validate engineering phase ({type(exc).__name__}). Fail closed and ask a human to inspect the state.", file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())

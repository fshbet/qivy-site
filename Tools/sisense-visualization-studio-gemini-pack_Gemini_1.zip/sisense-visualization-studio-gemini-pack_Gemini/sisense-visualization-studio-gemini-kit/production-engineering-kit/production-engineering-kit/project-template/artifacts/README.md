Store generated test reports, scan reports, build manifests and other release evidence here. Do not commit secrets or sensitive production data.

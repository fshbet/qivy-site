# Testing rules

- Map tests to acceptance criteria and risks.
- Add regression tests for defects.
- Test positive, negative, boundary, permission, failure and concurrency behavior as applicable.
- Keep tests deterministic and use controlled/disposable test infrastructure.
- Never weaken assertions or remove tests merely to obtain a passing result.
- Record exact commands and results; unexecuted checks are NOT VERIFIED.
- Do not use code coverage as the sole measure of test adequacy.

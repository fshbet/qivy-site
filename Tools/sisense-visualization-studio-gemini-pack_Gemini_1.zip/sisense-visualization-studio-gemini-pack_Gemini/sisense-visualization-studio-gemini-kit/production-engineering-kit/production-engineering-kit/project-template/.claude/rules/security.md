# Security rules

- Apply server-side authorization to every protected action and object.
- Deny by default and test unauthorized and cross-tenant access.
- Use maintained identity/cryptography libraries; never invent security primitives.
- Never hardcode secrets or include sensitive data in logs/errors.
- Use parameterized database operations and context-aware output encoding.
- Validate inputs and apply limits to uploads, requests and expensive operations.
- Review dependencies and supply-chain risk.
- Security checks must produce actual evidence; never claim security based on prompt compliance alone.
- Never run destructive security tests against production.

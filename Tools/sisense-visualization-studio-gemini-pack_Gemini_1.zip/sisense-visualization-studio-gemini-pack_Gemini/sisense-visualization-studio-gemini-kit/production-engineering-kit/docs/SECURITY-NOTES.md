# Security and enforcement notes

1. This package provides process guidance and some enforcement scaffolding, not a guarantee.
2. Claude Code hooks only cover the tools and invocation paths they are configured to match. Shell, MCP, external agents or alternate write paths may bypass direct-edit hooks.
3. Never grant an agent unrestricted access to production credentials, privileged shells or production systems.
4. Run coding agents in a least-privilege workspace; use containers or other isolation where appropriate.
5. Protect `.engineering/state.json` and approval scripts from agent edits. For stronger controls, store approvals in a protected CI environment or external approval service.
6. Require branch protection, code-owner review and mandatory CI checks on the hosting platform.
7. Do not make production deployment available to the coding agent by default.
8. Validate the hook schema against the installed Claude Code version and test that it blocks writes before approval and permits them after approval.

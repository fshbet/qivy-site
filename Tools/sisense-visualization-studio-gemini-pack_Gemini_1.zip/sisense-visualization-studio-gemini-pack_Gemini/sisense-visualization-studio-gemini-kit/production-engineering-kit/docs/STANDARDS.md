# Standards references

Verify current revisions and applicability during each project:
- NIST SSDF: https://csrc.nist.gov/projects/ssdf
- OWASP ASVS: https://owasp.org/www-project-application-security-verification-standard/
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- OWASP API Security: https://owasp.org/www-project-api-security/
- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- ISO/IEC 25010: https://www.iso.org/standard/78176.html

These are reference baselines, not blanket certification. Record the versions, controls selected, exclusions and evidence appropriate to the project. Apply organization-specific policies and applicable law/contractual requirements.

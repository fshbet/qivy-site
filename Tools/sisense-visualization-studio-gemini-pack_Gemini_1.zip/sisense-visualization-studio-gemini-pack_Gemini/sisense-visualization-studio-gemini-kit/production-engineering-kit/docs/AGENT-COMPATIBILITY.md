# Agent compatibility

This package is Claude Code-oriented because it uses `CLAUDE.md`, `.claude/rules/`, `.claude/skills/` and Claude Code hooks.

For other agents:
- OpenCode: adapt the constitution to `AGENTS.md` and its `.opencode/agents/` / skill configuration supported by your installed version.
- Codex: adapt the policy to `AGENTS.md` and repository-specific instructions.
- OpenHands: provide the constitution and skills as task/repository instructions and enforce gates externally in CI.
- Other agents: import the policy text and workflow artifacts, but do not assume Claude Code hooks are portable.

The approval-state hook is not a universal security boundary. Enforce policy using repository permissions, protected branches, CI checks, isolated execution, and human approval.

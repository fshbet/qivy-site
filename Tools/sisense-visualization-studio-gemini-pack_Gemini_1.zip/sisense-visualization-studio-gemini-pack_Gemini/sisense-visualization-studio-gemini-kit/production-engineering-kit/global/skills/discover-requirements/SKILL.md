---
name: discover-requirements
description: Discover and document business requirements, user journeys, constraints and testable acceptance criteria before application design or implementation.
---

# Requirements Discovery

- Inspect repository/context first.
- Identify users, goals, workflows, roles, permissions, data, integrations, constraints and failure cases.
- Capture functional requirements and non-functional requirements: security, privacy, accessibility, performance, availability, maintainability, portability, observability and recovery as applicable.
- Separate confirmed facts, assumptions, open questions and out-of-scope items.
- Ask focused questions for decisions that materially affect safety, architecture, data, cost or scope.
- Write requirements and acceptance criteria in testable, unambiguous language.
- Include positive, negative, boundary, permission and failure scenarios.
- Map each requirement to planned verification evidence.
- Do not start implementation during discovery.

---
name: validate-quality
description: Validate application correctness, testing completeness, usability, accessibility, maintainability and operational quality.
---

# Quality Validation

- Map acceptance criteria to tests and evidence.
- Run format/lint, type/static checks, unit, integration, contract, end-to-end and regression tests appropriate to the stack.
- Test invalid input, boundaries, permissions, concurrent operations, retries, timeouts and service failures.
- Validate database constraints, migrations and transaction behavior.
- Review UI loading/empty/error/success states, responsive behavior, keyboard navigation, semantics, contrast and form errors.
- Run dependency/secret/SAST/container/IaC scans where applicable.
- Run build and smoke tests against a representative deployment configuration.
- Review logging, metrics, health checks, backup/restore and rollback documentation where relevant.
- Record exact commands, exit codes, counts, skipped tests and environmental limitations.
- Do not use line coverage as the sole quality indicator or lower thresholds to pass.

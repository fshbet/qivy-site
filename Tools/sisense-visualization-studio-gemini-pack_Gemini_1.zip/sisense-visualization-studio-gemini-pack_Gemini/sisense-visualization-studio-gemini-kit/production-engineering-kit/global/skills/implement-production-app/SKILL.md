---
name: implement-production-app
description: Implement an approved application plan in small, tested, documented and reviewable increments.
---

# Production Implementation

Prerequisite: the user has approved the architecture and implementation plan.

- Recheck Git status and protect user changes.
- Work in small vertical slices mapped to acceptance criteria.
- Follow the chosen stack's official conventions and security guidance.
- Add/update tests with each behavior change.
- Validate inputs at trust boundaries; authorize server-side; use parameterized queries and safe output encoding.
- Handle errors, timeouts, retries, cancellation and concurrency intentionally.
- Add migrations and test forward/recovery behavior.
- Implement accessible UI states and responsive behavior.
- Externalize secrets/configuration; provide safe `.env.example` or equivalent.
- Update docs, API specifications, ADRs and runbooks.
- Run relevant checks after each milestone; report exact results.
- Never claim unexecuted tests passed.
- Stop and request approval for material architecture, scope, cost, privacy or security changes.

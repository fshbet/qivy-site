---
name: design-architecture
description: Design and review architecture for new applications or major changes, including data, API, security, reliability and deployment decisions.
---

# Architecture Design

- Inspect current system and constraints before proposing a design.
- Choose the simplest architecture that meets requirements; justify alternatives.
- Define component boundaries, dependency direction, data flow and external trust boundaries.
- Define domain/data model, keys, constraints, indexes, transactions, migrations, retention and recovery.
- Define API contracts, authentication/authorization, error conventions, versioning, idempotency and rate limits as applicable.
- Define tenancy/isolation, audit events, secrets, observability and operational dependencies.
- Include threat-model summary, performance/reliability expectations and failure modes.
- Create C4 diagrams where useful and ADRs for material decisions.
- Define implementation milestones and measurable acceptance criteria.
- Record assumptions and risks.
- Stop and wait for explicit human approval before implementation.

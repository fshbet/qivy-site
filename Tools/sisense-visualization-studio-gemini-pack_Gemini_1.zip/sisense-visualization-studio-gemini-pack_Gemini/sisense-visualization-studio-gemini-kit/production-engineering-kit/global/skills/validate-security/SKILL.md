---
name: validate-security
description: Perform an evidence-based security review of application design and code, especially before merging or release.
---

# Security Validation

- Define scope, trust boundaries, assets and threat scenarios.
- Use current applicable OWASP ASVS requirements for web apps and relevant platform guidance.
- Review authentication, sessions, recovery, authorization, object ownership, tenant isolation and privilege escalation.
- Review injection, XSS, CSRF, SSRF, unsafe file handling, command execution, deserialization, secrets, logging, rate limiting, CORS, security headers, TLS, dependencies and configuration as applicable.
- Run approved scanners and record tool/version, scope, command and result.
- Report findings with severity, evidence, affected component, impact, reproduction and remediation.
- Distinguish scanner findings from verified vulnerabilities and record scan limitations.
- Never test destructive actions against production.
- Never state “secure” or “no vulnerabilities” solely because a scanner found none.
- Verify fixes with regression tests and rerun relevant scans.

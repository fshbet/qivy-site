---
name: verify-release-readiness
description: Determine whether an application or change meets its agreed release criteria using evidence, not claims.
---

# Release Readiness Review

1. Read approved requirements, acceptance criteria, architecture, threat model and release policy.
2. Inspect Git diff, dependencies, secrets handling, migrations and deployment configuration.
3. Run or verify actual required lint, type, test, scan and build commands.
4. Verify critical authentication/authorization paths and negative cases.
5. Verify artifact reproducibility and environment configuration.
6. Check monitoring, health/readiness, backup/restore, rollback and operational runbooks as applicable.
7. Map every release gate to evidence, status and limitations.
8. Identify known defects, security findings, untested areas, external prerequisites and residual risks.
9. Recommend GO or NO-GO. Never authorize deployment on behalf of the human.
10. Do not claim formal certification, independent audit, compliance or production validation without evidence.

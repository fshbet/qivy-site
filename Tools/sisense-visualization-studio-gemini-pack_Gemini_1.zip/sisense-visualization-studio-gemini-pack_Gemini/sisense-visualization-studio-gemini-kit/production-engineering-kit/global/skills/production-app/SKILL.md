---
name: production-app
description: End-to-end workflow for building or materially changing an application to an evidence-based production-readiness standard. Use whenever the user asks to build, create, rebuild, modernize or significantly extend an application.
---

# Production Application Lifecycle

This skill is the entry point. Follow the global engineering constitution and project instructions.

1. Inspect the repository and current Git status; do not overwrite existing work.
2. Discover the product, users, constraints, data classification, integrations and deployment target.
3. Determine the application profile (web/SaaS, mobile, desktop, API/service, data/BI, AI/agent, automation) and load the relevant skills.
4. Create requirements, acceptance criteria, architecture, threat model, UX plan, test strategy, deployment plan and milestone backlog.
5. Stop before substantial implementation and request explicit approval of the plan. If a valid project approval gate is configured, it must be updated by the human—not by the agent.
6. Implement one milestone at a time. Each milestone must include tests, documentation and an evidence record.
7. Run independent QA, security, UX/accessibility and architecture reviews appropriate to risk.
8. Verify build, configuration, migrations, deployment and rollback to the agreed environment.
9. Produce a release-readiness report with GO/NO-GO recommendation, exact evidence, unresolved risks and external prerequisites.
10. Do not deploy or claim verified production readiness without the necessary authorization and evidence.

Required artifacts should be stored in the repository under `docs/` and `artifacts/` as appropriate. Do not fabricate evidence or approvals.

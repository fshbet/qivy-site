---
name: design-user-experience
description: Design user-friendly, modern, accessible and responsive UX for applications before or during approved implementation.
---

# UX and Accessibility Design

- Identify primary personas, tasks, user journeys and usability risks.
- Define information architecture, navigation, page states, interaction patterns and design tokens.
- Use a consistent visual system appropriate to the product and brand; do not add decorative complexity that harms clarity.
- Specify responsive behavior for relevant viewport sizes.
- Specify loading, empty, error, success, validation, permission-denied, offline and retry states where applicable.
- Target WCAG 2.2 AA for applicable web interfaces unless another target is justified.
- Include keyboard-only navigation, focus visibility/order, semantic landmarks, accessible names, contrast, form labels, error association and reduced-motion considerations.
- Avoid dead controls, placeholder functionality and deceptive demo data.
- Define usability acceptance criteria and validation methods.
- Do not claim accessibility certification or user research without evidence.

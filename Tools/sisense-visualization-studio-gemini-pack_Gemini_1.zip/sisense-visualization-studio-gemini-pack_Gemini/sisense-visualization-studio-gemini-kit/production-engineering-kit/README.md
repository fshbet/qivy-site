# Production Engineering Kit

A reusable engineering policy and Claude Code skill pack intended to make application-building workflows follow a repeatable, evidence-based delivery process.

## What this package does

- Requires discovery and architecture planning before substantial implementation.
- Provides reusable skills for requirements, architecture, UX, implementation, security, QA, and release readiness.
- Includes templates for architecture, threat models, test plans, ADRs, deployment runbooks, and release evidence.
- Includes a lightweight approval-state gate and CI template.
- Encourages technology-appropriate standards rather than forcing one stack on every application.

## Important limitation

Instructions and skills alone cannot guarantee production readiness. Claude Code hooks can block common direct file-editing tools before approval, but no prompt or hook can prevent every possible bypass. Keep the project under version control, review changes, restrict tool permissions, and enforce mandatory checks in CI and repository rules. A passing checklist is not a certification or guarantee of security.

## Install globally for Claude Code

1. Unzip this package.
2. Copy `global/CLAUDE.md` to `%USERPROFILE%\.claude\CLAUDE.md` (merge with existing content; do not overwrite unrelated personal rules).
3. Copy `global/skills/` into `%USERPROFILE%\.claude\skills\`.
4. Review `global/settings.example.json`. Do not replace your existing Claude Code settings without merging them.

PowerShell example:

```powershell
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Copy-Item .\global\CLAUDE.md "$HOME\.claude\CLAUDE.md"
Copy-Item .\global\skills\* "$HOME\.claude\skills\" -Recurse -Force
```

If you already have a `CLAUDE.md`, merge the rules manually instead of overwriting it.

## Install in a project

Copy the contents of `project-template/` into the root of a new or existing repository. Review `CLAUDE.md` and fill in `docs/project-context.md` for the specific project.

```powershell
Copy-Item .\project-template\* C:\path\to\your-project\ -Recurse -Force
```

For an existing project, inspect and merge files carefully; never overwrite existing project configuration blindly.

## Start a new application

1. Open the repository in Claude Code.
2. Run `/production-app` or `/discover-requirements`.
3. Require the agent to inspect the repository and create the planning artifacts.
4. Review the plan and approve it explicitly. Use the approval script described below.
5. Implement one milestone at a time.
6. Run all relevant quality gates and inspect evidence.
7. Require an independent release-readiness review.

## Approval gate (optional, recommended)

The project template contains `.engineering/state.json`, scripts, and a Claude Code `PreToolUse` hook. The hook blocks common direct file-writing tools until the state is `implementation_approved`. It is deliberately fail-closed when state is missing or malformed.

After reviewing the plan, run:

```powershell
.\scripts\approve-plan.ps1
```

The script asks for an explicit typed confirmation and updates the state. Do not let the agent approve its own plan. For additional milestones or sensitive changes, use human review and branch protections.

After implementation and verification, record the final release review:

```powershell
.\scripts\record-release-review.ps1
```

This script records a recommendation, not a deployment authorization. Production deployment should remain a separate protected action.

### Hook limitations

- Claude Code hook behavior and settings schemas can change; validate against the version installed in your environment.
- The hook covers direct `Write`, `Edit`, and `MultiEdit` tool calls. Shell commands, external tools, other agents, or user-level configuration may bypass it. Restrict shell permissions and use CI/branch protection for enforceable controls.
- Never run agent-generated scripts with elevated privileges or production credentials without review.

## Quality gates

Customize `.engineering/quality-gates.json` to the stack. Do not leave placeholder commands as if they were executed. A gate is only satisfied when its real command runs successfully and evidence is retained.

## Standards baseline

Use relevant current versions of:
- NIST Secure Software Development Framework (SSDF)
- OWASP ASVS and relevant OWASP guidance
- WCAG 2.2 AA for applicable web interfaces
- ISO/IEC 25010 as a software quality model
- Language/framework official secure coding guidance
- Organization-specific policies and regulatory obligations

Verify current versions and applicability for each project. This kit does not confer certification or guarantee legal compliance.

## Contents

- `global/`: user-wide Claude Code policy and reusable skills.
- `project-template/`: project-level rules, skills, templates, gate scripts, hooks, CI example.
- `docs/`: setup and enforcement guidance.
